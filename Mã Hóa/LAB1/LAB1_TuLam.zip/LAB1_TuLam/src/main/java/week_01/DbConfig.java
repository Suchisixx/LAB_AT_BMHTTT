package week_01;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Lưu thông tin kết nối Oracle Database mà sinh viên nhập trên form frm_KetNoiOracle.
 * Mật khẩu chỉ nằm trong bộ nhớ khi chương trình chạy, KHÔNG ghi vào mã nguồn hay tệp.
 */
public final class DbConfig {
    private static String server;
    private static int port = 1521;
    private static String database; // Service name (ví dụ: FREE hoặc FREEPDB1)
    private static String user;
    private static char[] password;

    private DbConfig() {
    }

    /** Ghi nhớ thông tin kết nối (gọi khi bấm nút Test Connection). */
    public static synchronized void set(String newServer, int newPort, String newDatabase,
                                       String newUser, char[] newPassword) {
        if (newServer == null || newServer.isBlank()
                || newDatabase == null || newDatabase.isBlank()
                || newUser == null || newUser.isBlank()) {
            throw new IllegalArgumentException("Server, Service Name/Database và User không được để trống.");
        }
        if (newPort < 1 || newPort > 65535) {
            throw new IllegalArgumentException("Port phải nằm trong khoảng 1 - 65535.");
        }
        server = newServer.trim();
        port = newPort;
        database = newDatabase.trim();
        user = newUser.trim();
        password = newPassword != null ? newPassword.clone() : new char[0];
    }

    /** Xóa cấu hình (dùng khi kết nối thất bại). */
    public static synchronized void clear() {
        server = null;
        password = null;
    }

    /** true nếu đã nhập cấu hình và kết nối thử thành công. */
    public static synchronized boolean isReady() {
        return server != null;
    }

    /** Mở một kết nối JDBC mới; nhớ đóng bằng try-with-resources. */
    public static synchronized Connection open() throws SQLException {
        if (server == null) {
            throw new SQLException("Chưa cấu hình Oracle Database. Hãy mở form Kết nối Oracle và bấm Test Connection.");
        }

        // Cú pháp kết nối Oracle Easy Connect Plus
        String url;
        if (database.startsWith("/") || database.startsWith(":")) {
            url = "jdbc:oracle:thin:@" + server + ":" + port + database;
        } else {
            url = "jdbc:oracle:thin:@//" + server + ":" + port + "/" + database;
        }

        try {
            Class.forName("oracle.jdbc.OracleDriver");
        } catch (ClassNotFoundException e) {
            // Driver có thể đã được tự động nạp bởi ServiceLoader của JDBC 4.0+
        }

        DriverManager.setLoginTimeout(5);
        return DriverManager.getConnection(url, user, new String(password));
    }

    /** Kết nối thử; trả về chuỗi mô tả để hiện lên form. */
    public static String test() throws SQLException {
        try (Connection con = open()) {
            DatabaseMetaData md = con.getMetaData();
            return "Kết nối thành công: " + md.getDatabaseProductName() + " "
                    + md.getDatabaseProductVersion() + " (User: " + md.getUserName() + ")";
        }
    }
}
